#include "libs.h" //basic libraries (glm, iostrem, etc.)
#include "util.h" //stray functions that would clutter the main (draw_square, draw, etc.)

int main(int argc, const char * argv[]) {
    load_scene("scene1.txt");
    return 0;
}
