#pragma once
#include "libs.h"
const char* get_name();
void draw_square(cimg_library::CImg<float> &image, int width, int height);
void draw(cimg_library::CImg<float> &image, int w, int h, glm::vec3 color);
bool load_scene(const std::string& filepath);
