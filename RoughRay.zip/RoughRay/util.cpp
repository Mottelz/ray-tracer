#include "util.h"

//Load the data of a file
bool load_scene(const std::string& filepath) {
    FILE * file = fopen(filepath.c_str(), "r");
    int num_objects;
    if (file == NULL) {
        std::cout << "Scene failed to load!" <<std::endl;
        return false;
    }
    
    //Read in the numbed of objects as the first line
    fscanf(file, "%i\n", &num_objects);
    if (num_objects == 0) {
        std::cout << "Missing number of objects in the scene!" << std::endl;
        return false;
    } else {
        printf("Number of objects in scene: %i\n", num_objects);
    }
    
    
    
    //Read in the rest of the scene
    for (int i = 0; i < num_objects; i++) {
        //read in the line header
        char lineHeader[128];
        fscanf(file, "%s\n", lineHeader); //read in object header
        
        //Read in a camera
        if (strcmp(lineHeader, "camera") == 0) {
            glm::vec3 temp_pos(-1.0f);
            int temp_fov;
            int temp_f;
            float temp_a;
            for (int i = 0; i < 5; i++) {
                fscanf(file, "%s: ", lineHeader);
                if (strcmp(lineHeader, "pos")) {
                    fscanf(file, "%i %i %i\n", &temp_pos.x, &temp_pos.y, &temp_pos.z);
                } else if (strcmp(lineHeader, "fov")) {
                    fscanf(file, "%i\n", &temp_fov);
                } else if (strcmp(lineHeader, "f")) {
                    fscanf(file, "%i\n", &temp_f);
                } else if (strcmp(lineHeader, "a")) {
                    fscanf(file, "%f\n", &temp_a);
                } else {
                    std::cout << "Camera is missing info!" << std::endl;
                    return false;
                }
            }
            printf("Camera Specs: \n  Position: %s\n  FoV: %f\n  Aspect Ratio: %f\n  Focal Length: %i\n", glm::to_string(temp_pos).c_str(), temp_fov, temp_a, temp_f);
        }
        //Read in the plane
        else if (strcmp(lineHeader, "plane") == 0) {
            glm::vec3 temp_norm;
            glm::vec3 temp_pos;
            glm::vec3 temp_amb;
            glm::vec3 temp_dif;
            glm::vec3 temp_spe;
            int temp_shi;
            for (int i = 0; i < 7; i++) {
                fscanf(file, "%s: ", lineHeader);
                if (strcmp(lineHeader, "nor")) {
                    fscanf(file, "%i %i %i\n", &temp_norm.x, &temp_norm.y, &temp_norm.z);
                } else if (strcmp(lineHeader, "pos")) {
                    fscanf(file, "%i %i %i\n", &temp_pos.x, &temp_pos.y, &temp_pos.z);
                } else if (strcmp(lineHeader, "amb")) {
                    fscanf(file, "%f %f %f\n", &temp_amb.x, &temp_amb.y, &temp_amb.z);
                } else if (strcmp(lineHeader, "dif")) {
                    fscanf(file, "%f %f %f\n", &temp_dif.x, &temp_dif.y, &temp_dif.z);
                } else if (strcmp(lineHeader, "spe")) {
                    fscanf(file, "%f %f %f\n", &temp_spe.x, &temp_spe.y, &temp_spe.z);
                } else if (strcmp(lineHeader, "shi")) {
                    fscanf(file, "%i\n", &temp_shi);
                } else {
                    std::cout << "Plane is missing info" << std::endl;
                    return false;
                }
            }
            printf("Plane Specs: \n  Norm: %s\n  Position: %s\n  Ambient: %s\n  Diffuse: %s\n  Specular: %s\n  Shine: %i\n", glm::to_string(temp_pos).c_str(),
                   glm::to_string(temp_norm).c_str(),
                   glm::to_string(temp_pos).c_str(),
                   glm::to_string(temp_amb).c_str(),
                   glm::to_string(temp_dif).c_str(),
                   glm::to_string(temp_spe).c_str(),
                   temp_shi);
        } else if (strcmp(lineHeader, "sphere") == 0) {
            std::cout << "Sphere" << std::endl;
        } else if (strcmp(lineHeader, "light") == 0) {
            std::cout << "Light" << std::endl;
        } else {
            std::cout << "We're reading the scene wrong!" << std::endl;
        }
    }
    return true;
};

//Create filename with timestamp
const char* get_name() {
    //Get time
    auto t = std::time(nullptr);
    auto tm = *std::localtime(&t);
    //Convert time to stream
    std::ostringstream oss;
    oss << std::put_time(&tm, "%y-%m-%d %Hh%Mm%Ss");
    //Create the string and return it
    std::string filename = "render " + oss.str() + ".png";
    return filename.c_str();
}

//Draw a 150x150 pink square in the centre of an image
void draw_square(cimg_library::CImg<float> &image, int width, int height) {
    //Draw a pink square in the centre
    glm::vec3 color(64, 0, 77);
    for (int j = (width/2)-75; j < (width/2)+75; j++) {
        for (int k = (height/2)-75; k < (height/2)+75; k++) {
            image(j, k, 0) = color.x;
            image(j, k, 1) = color.y;
            image(j, k, 2) = color.z;
        }
    }
}

//Set the colour of a given pixel
void draw(cimg_library::CImg<float> &image, int w, int h, glm::vec3 color) {
    //Color in a given pixel
    image(w, h, 0) = color.x;
    image(w, h, 1) = color.y;
    image(w, h, 2) = color.z;
}
